package domain;

public enum Sex {
	
	
	
	MALE,FEMALE

}

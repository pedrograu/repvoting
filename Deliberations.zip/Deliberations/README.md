Proyecto EGC con DP
